#include <nebula_sdk/nebula_sdk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/resource.h>
#include <limits.h>

void OnPush(const char* data, int len)
{
    char *body = strndup(data, len);
    printf("recv push:%s\n", body);
    free(body);
}

int main()
{
    struct rlimit no_limit = {RLIM_INFINITY, RLIM_INFINITY};
    setrlimit(RLIMIT_CORE, &no_limit);

    if (-1 == NebulaInit("1000000010000001", "https://172.16.82.71", "data")) {
        printf("Init error.\n");
        return 1;
    }

    const char * apps[] = {"com.meizu.cloud"};
    NebulaSubScribe(1, apps);
    NebulaRegister(eNebulaMsg_Push, &OnPush);

    if (-1 == NebulaStart()) {
        printf("Start error.\n");
        return 1;
    }

    printf("start success.\n");

    for (;;)
        sleep(1);

    return 0;
}

