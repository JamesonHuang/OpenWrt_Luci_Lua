#ifndef REDIRECT_H
#define REDIRECT_H

/** redirect
 * @Launch http request to p.meizu.com, get server ip list.
 * @Block function.
 */
int NebulaRedirect();

#endif //REDIRECT_H
