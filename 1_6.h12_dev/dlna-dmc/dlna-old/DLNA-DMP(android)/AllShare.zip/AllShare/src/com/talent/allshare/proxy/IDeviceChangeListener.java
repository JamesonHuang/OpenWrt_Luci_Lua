package com.talent.allshare.proxy;

public interface IDeviceChangeListener {

	public void onDeviceChange(boolean isSelDeviceChange);
}
